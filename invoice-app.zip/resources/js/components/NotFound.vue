<template>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <div class="card p-2">
                <h1>Page not found</h1>
                <br>
                <router-link to="/" >Back To Home Page</router-link>
            </div>
        </div>
        <div class="col-md-4"></div>
    </div>
</template>